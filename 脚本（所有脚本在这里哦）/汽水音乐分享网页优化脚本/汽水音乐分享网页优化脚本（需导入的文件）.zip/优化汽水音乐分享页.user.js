// ==UserScript==
// @name         优化汽水音乐分享页
// @namespace    http://tampermonkey.net/
// @version      3.1
// @description  优化汽水音乐分享页，防止流氓操作，增加下载音频功能，拦截弹窗
// @author       小狸
// @match        https://music.douyin.com/qishui/share/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

//---------------------------------------------------------------------------------------------
// 作用的网页：汽水音乐分享页面（比如：https://qishui.douyin.com/s/i97MHGLp/）
// 这个脚本加载后分享页的顶部推广会会消失，这就说明你已经成功来到纯净版的分享页
// 脚本的功能：删除了推广元素、流氓下载设计和弹窗广告，增加了底部标语，覆写了下载按钮
// 注意，脚本生效的标志是顶部推广会会消失，否则就是没有生效。首次打开页面可能不起作用，需要刷新
// 目前仅测试了电脑端的分享网页，手机如果使用该脚本，下载功能不会生效（正在修复），但其他的可以
//---------------------------------------------------------------------------------------------
// 汽水音乐的分享页真是流氓，随便一点就要求下载软件，真是烦死了，还有那个下载按钮，简直就是一个
// 流氓设计，下载的是安装程序，简直气死我了，我直接覆写下载按钮变成真正的下载音乐的按钮，点一下
// 是真的下载指定的音频文件。也不知道是那个SB想的这个分享页，但是有一点比较好，有播放功能，也有
// 歌词，简直就是一个网页版播放器，就是加了一些流氓功能。
//---------------------------------------------------------------------------------------------

(function() {
    'use strict';

    console.log('油猴脚本: 开始初始化...');

    // 只在目标链接下执行
    if (!window.location.href.startsWith('https://music.douyin.com/qishui/share/')) {
        console.log('油猴脚本: 不在目标页面，退出');
        return;
    }

    let initialized = false;

    /**
     * 拦截seo-modal-container弹窗
     */
    function interceptSeoModal() {
        console.log('油猴脚本: 开始拦截seo-modal-container弹窗');

        // 立即移除已存在的弹窗
        const removeModal = () => {
            const modals = document.querySelectorAll('.seo-modal-container');
            modals.forEach(modal => {
                // 检查弹窗文案是否包含「打开汽水畅听全曲」
                if (modal.textContent.includes('打开汽水畅听全曲')) {
                    modal.remove();
                    console.log('油猴脚本: 已移除seo-modal-container弹窗');
                }
            });

            // 移除luna-toast弹窗黑幕
            const lunaToast = document.getElementById('luna-toast');
            if (lunaToast) {
                lunaToast.remove();
                console.log('油猴脚本: 已移除luna-toast弹窗黑幕');
            }

            // 移除其他可能的弹窗黑幕
            const blackMasks = document.querySelectorAll('div[style*="background: rgba(18, 18, 18, 0.35)"]');
            blackMasks.forEach(mask => {
                mask.remove();
                console.log('油猴脚本: 已移除弹窗黑幕');
            });
        };

        // 立即执行一次
        removeModal();

        // 使用MutationObserver监听DOM变化
        const observer = new MutationObserver((mutations) => {
            mutations.forEach(mutation => {
                if (mutation.addedNodes.length > 0) {
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            // 检查新增节点是否是目标弹窗
                            if (node.classList && node.classList.contains('seo-modal-container')) {
                                if (node.textContent.includes('打开汽水畅听全曲')) {
                                    node.remove();
                                    console.log('油猴脚本: 拦截到动态加载的seo-modal-container弹窗');
                                }
                            }
                            // 检查子节点
                            const modals = node.querySelectorAll('.seo-modal-container');
                            modals.forEach(modal => {
                                if (modal.textContent.includes('打开汽水畅听全曲')) {
                                    modal.remove();
                                    console.log('油猴脚本: 拦截到动态加载的seo-modal-container弹窗');
                                }
                            });

                            // 检查是否是luna-toast弹窗
                            if (node.id === 'luna-toast') {
                                node.remove();
                                console.log('油猴脚本: 拦截到luna-toast弹窗');
                            }

                            // 检查是否包含弹窗黑幕
                            const blackMasks = node.querySelectorAll('div[style*="background: rgba(18, 18, 18, 0.35)"]');
                            blackMasks.forEach(mask => {
                                mask.remove();
                                console.log('油猴脚本: 拦截到弹窗黑幕');
                            });
                        }
                    });
                }
            });
        });

        // 监听整个文档
        observer.observe(document, {
            childList: true,
            subtree: true
        });

        console.log('油猴脚本: seo-modal-container弹窗拦截器已设置');
    }

    /**
     * 删除顶部banner元素
     */
    function removeTopBanner() {
        let removed = false;

        // 查找并删除顶部横幅
        const headerElement = document.querySelector('header.top-banner-br');
        if (headerElement) {
            headerElement.remove();
            console.log('油猴脚本: 已成功删除顶部banner元素');
            removed = true;
        }

        // 也尝试通过其他选择器查找类似的横幅
        const possibleBanners = document.querySelectorAll('header[class*="top"], header[class*="banner"], .top-banner, [class*="top-banner"]');
        possibleBanners.forEach(banner => {
            if (banner.textContent.includes('汽水') || banner.textContent.includes('邀请') || banner.classList.contains('top-banner-br')) {
                banner.remove();
                console.log('油猴脚本: 已删除横幅广告元素');
                removed = true;
            }
        });

        return removed;
    }

    /**
     * 拦截整个top-part区域内的所有点击事件
     * 使用事件捕获阶段 (true) 以确保在页面自身监听器之前拦截
     * 但只允许自定义下载按钮点击
     */
    function setupClickBlocker() {
        document.addEventListener('click', function(event) {
            const target = event.target;

            // 多种方式检查是否是自定义下载按钮
            const isDownloadButton =
                (target.classList && target.classList.contains('custom-download-button')) ||
                (target.dataset && target.dataset.customDownload) ||
                (target.closest && target.closest('[data-custom-download="true"]')) ||
                (target.closest && target.closest('.custom-download-button'));

            if (isDownloadButton) {
                console.log('油猴脚本: 允许下载按钮点击', target);
                return;
            }

            // 查找点击的元素是否在top-part区域内
            const topPart = target.closest('.top-part');
            if (topPart) {
                console.log('油猴脚本: 拦截了top-part区域内的点击', target);
                event.preventDefault();
                event.stopPropagation();
                event.stopImmediatePropagation();
                return;
            }
        }, true);
        console.log('油猴脚本: 点击拦截器已设置');
    }

    /**
     * 清理文件名，移除非法字符
     */
    function sanitizeFileName(name) {
        if (!name) return name;
        // 移除文件名中不能包含的字符
        return name.replace(/[\/:*?"<>|]/g, '_').trim();
    }

    /**
     * 检测音乐文件地址和名称
     */
    function detectMusicInfo() {
        let musicUrl = '';
        let musicName = '';

        // 从audio元素获取
        const audioElement = document.getElementById('--luna-view-player--');
        if (audioElement && audioElement.src) {
            musicUrl = audioElement.src;
            console.log('油猴脚本: 从audio元素检测到音乐地址:', musicUrl);
        }

        // 方法1：从.music-info .name获取
        const titleElement = document.querySelector('.music-info .name');
        if (titleElement && titleElement.textContent.trim()) {
            musicName = sanitizeFileName(titleElement.textContent.trim());
            console.log('油猴脚本: 从.music-info .name检测到音乐名称:', musicName);
        }

        // 方法2：从页面中所有可能的标题元素获取
        if (!musicName) {
            const possibleSelectors = [
                'h1', 'h2', '.title', '.music-name', '.track-name', '.song-name',
                '.music-title', '.track-title', '.song-title', '[class*="name"]', '[class*="title"]'
            ];
            for (const selector of possibleSelectors) {
                const elements = document.querySelectorAll(selector);
                for (const el of elements) {
                    const text = el.textContent.trim();
                    if (text && text.length > 0 && text.length < 100) {
                        musicName = sanitizeFileName(text);
                        console.log('油猴脚本: 从选择器', selector, '检测到音乐名称:', musicName);
                        break;
                    }
                }
                if (musicName) break;
            }
        }

        // 方法3：从页面标题获取
        if (!musicName) {
            const pageTitle = document.title;
            if (pageTitle) {
                if (pageTitle.includes('@')) {
                    musicName = sanitizeFileName(pageTitle.split('@')[0].trim());
                } else {
                    musicName = sanitizeFileName(pageTitle.trim());
                }
                console.log('油猴脚本: 从页面标题检测到音乐名称:', musicName);
            }
        }

        // 方法4：从脚本中提取
        if (!musicName || !musicUrl) {
            const scripts = document.querySelectorAll('script');
            for (const script of scripts) {
                if (script.textContent) {
                    // 提取音乐名称
                    if (!musicName) {
                        const nameMatch = script.textContent.match(/"title":"([^"]+)"/);
                        if (nameMatch && nameMatch[1]) {
                            musicName = sanitizeFileName(nameMatch[1]);
                            console.log('油猴脚本: 从脚本检测到音乐名称:', musicName);
                        }
                    }
                    // 提取音乐URL
                    if (!musicUrl) {
                        const urlMatch = script.textContent.match(/"url":"(https:\\u002F\\u002F[^"]+)"/);
                        if (urlMatch && urlMatch[1]) {
                            musicUrl = urlMatch[1].replace(/\\u002F/g, '/');
                            console.log('油猴脚本: 从脚本检测到音乐URL:', musicUrl);
                        }
                    }
                    if (musicName && musicUrl) break;
                }
            }
        }

        return { musicUrl, musicName };
    }

    /**
     * 下载音频文件（使用XMLHttpRequest确保直接下载）
     */
    function downloadAudio(url, filename) {
        if (!url) {
            console.error('油猴脚本: 没有检测到音乐文件地址');
            alert('未找到音乐文件地址，请稍后再试');
            return;
        }

        console.log('油猴脚本: 准备下载音频:', url);

        // 确保文件名以.mp3结尾
        let finalFilename = filename || 'audio.mp3';

        // 移除已有的音频扩展名
        finalFilename = finalFilename.replace(/\.(mp4|m4a|mp3|wav|flac|aac)$/i, '');

        // 添加.mp3扩展名
        finalFilename = finalFilename + '.mp3';

        console.log('油猴脚本: 最终文件名:', finalFilename);

        // 使用fetch下载文件
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error('网络响应异常');
                }
                return response.blob();
            })
            .then(blob => {
                console.log('油猴脚本: 文件下载完成，准备保存');
                const downloadUrl = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = downloadUrl;
                link.download = finalFilename;
                link.style.display = 'none';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                window.URL.revokeObjectURL(downloadUrl);
                console.log('油猴脚本: 文件已开始下载:', finalFilename);
            })
            .catch(error => {
                console.error('油猴脚本: 下载失败:', error);
                console.log('油猴脚本: 尝试备用下载方法');
                // 备用方法：直接打开链接
                const link = document.createElement('a');
                link.href = url;
                link.download = finalFilename;
                link.target = '_blank';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            });
    }

    /**
     * 创建自定义下载按钮
     */
    function createCustomDownloadButton(container) {
        if (!container) return;

        console.log('油猴脚本: 创建自定义下载按钮');

        // 检测是否有VIP图标
        const hasVipIcon = document.querySelector('img.vip-icon') !== null;
        console.log('油猴脚本: 是否有VIP图标:', hasVipIcon);

        // 保存原容器的位置信息和样式
        const containerStyle = window.getComputedStyle(container);
        const containerParent = container.parentNode;
        const containerNextSibling = container.nextSibling;

        // 保存原有的 left 部分（收藏、评论、分享按钮）
        const originalLeft = container.querySelector('.left');
        let leftClone = null;
        if (originalLeft) {
            leftClone = originalLeft.cloneNode(true);
        }

        // 完全移除原容器（清除所有事件监听器）
        container.remove();
        console.log('油猴脚本: 原容器已移除');

        // 创建全新的容器
        const newContainer = document.createElement('div');
        newContainer.className = 'action-container';
        newContainer.style.cssText = containerStyle.cssText;
        newContainer.style.position = 'relative';

        // 插入新容器
        containerParent.insertBefore(newContainer, containerNextSibling);
        container = newContainer;

        // 添加保存的 left 部分（保留原有样式和结构）
        if (leftClone) {
            container.appendChild(leftClone);
        }

        // 创建下载按钮（可点击区域）
        const downloadButton = document.createElement('img');
        downloadButton.className = 'right custom-download-button';
        downloadButton.src = 'https://lf-luna.qishui.com/obj/music-luna-fe/ies/luna-share-h5-edenx/static/image/download-black.0ad00942.png';
        downloadButton.style.cssText = `
            width: 24px;
            height: 24px;
            cursor: pointer;
        `;
        container.appendChild(downloadButton);

        // 警告提示（仅在有VIP图标时显示，放在下载按钮下方）
        if (hasVipIcon) {
            const warningSpan = document.createElement('span');
            warningSpan.className = 'vip-warning';
            warningSpan.style.cssText = 'font-size: 13px; color: #f0f0f0; text-shadow: 0 1px 2px rgba(0,0,0,0.1); margin-top: 4px; cursor: default; position: absolute; bottom: -20px; left: 50%; transform: translateX(-50%);';
            warningSpan.textContent = 'VIP音乐只能下载音乐片段';

            // 单独拦截警告文字的点击事件
            warningSpan.addEventListener('click', function(event) {
                event.preventDefault();
                event.stopPropagation();
                event.stopImmediatePropagation();
                console.log('油猴脚本: 点击了警告文字，已拦截');
            }, true);

            container.appendChild(warningSpan);
        }

        // 添加点击事件（只给按钮添加）- 使用捕获阶段，最高优先级
        downloadButton.addEventListener('click', function(event) {
            event.preventDefault();
            event.stopPropagation();
            event.stopImmediatePropagation();

            console.log('油猴脚本: 点击了自定义下载按钮');

            const { musicUrl, musicName } = detectMusicInfo();
            downloadAudio(musicUrl, musicName ? `${musicName}.mp3` : 'audio.mp3');
        }, true);

        // 同时添加 mousedown 和 touchstart 事件，确保所有设备都能触发
        ['mousedown', 'touchstart'].forEach(eventType => {
            downloadButton.addEventListener(eventType, function(event) {
                console.log('油猴脚本: 检测到 ' + eventType + ' 事件');
                event.preventDefault();
                event.stopPropagation();
                event.stopImmediatePropagation();
            }, true);
        });

        // 添加一个特殊属性，便于点击拦截器识别
        downloadButton.dataset.customDownload = 'true';

        console.log('油猴脚本: 自定义下载按钮创建完成');
    }

    /**
     * 覆写下载按钮功能
     */
    function modifyDownloadButton() {
        const actionContainer = document.querySelector('.action-container');
        if (actionContainer) {
            createCustomDownloadButton(actionContainer);
        }
    }

    /**
     * 在网页底部添加标语
     */
    function addFooterSlogan() {
        if (document.getElementById('custom-footer-slogan')) {
            return;
        }

        const slogan = document.createElement('div');
        slogan.id = 'custom-footer-slogan';
        slogan.style.cssText = `
            width: 100%;
            padding: 20px 0;
            font-size: 14px;
            color: #999;
            text-align: center;
            pointer-events: none;
        `;
        slogan.textContent = '让"分享"不再是软件的宣传   ---   让分享成为真正的分享';
        document.body.appendChild(slogan);
        console.log('油猴脚本: 已添加底部标语');
    }

    /**
     * 隐藏滚动条
     */
    function hideScrollbar() {
        const style = document.createElement('style');
        style.id = 'custom-hide-scrollbar-style';
        style.textContent = `
            html, body {
                -ms-overflow-style: none !important;
                scrollbar-width: none !important;
            }
            html::-webkit-scrollbar, body::-webkit-scrollbar {
                display: none !important;
            }
        `;
        if (!document.getElementById('custom-hide-scrollbar-style')) {
            document.head.appendChild(style);
            console.log('油猴脚本: 已隐藏滚动条');
        }
    }

    /**
     * 初始化脚本
     */
    function initialize() {
        if (initialized) {
            console.log('油猴脚本: 已经初始化过了');
            return;
        }

        console.log('油猴脚本: 开始初始化...');

        // 删除顶部banner
        removeTopBanner();

        // 设置点击拦截器
        setupClickBlocker();

        // 修改下载按钮
        modifyDownloadButton();

        // 添加底部标语
        addFooterSlogan();

        // 隐藏滚动条
        hideScrollbar();

        // 使用MutationObserver持续监听
        const observer = new MutationObserver((mutations) => {
            // 检查是否需要重新添加顶部banner删除 - 更彻底的检查
            removeTopBanner();

            // 检查是否需要重新创建下载按钮
            const actionContainer = document.querySelector('.action-container');
            if (actionContainer && !actionContainer.querySelector('.custom-download-button')) {
                console.log('油猴脚本: 检测到下载按钮被重置，重新创建');
                createCustomDownloadButton(actionContainer);
            }

            // 检查是否需要重新添加底部标语
            if (!document.getElementById('custom-footer-slogan')) {
                addFooterSlogan();
            }

            // 检查是否需要重新隐藏滚动条
            if (!document.getElementById('custom-hide-scrollbar-style')) {
                hideScrollbar();
            }
        });

        // 修复点：检查 document.body 是否存在
        if (document.body) {
            // 观察整个文档
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
            console.log('油猴脚本: MutationObserver 已启动');
        } else {
            console.log('油猴脚本: document.body 尚不存在，等待 DOMContentLoaded');
            // 等待 DOM 加载完成后启动观察器
            document.addEventListener('DOMContentLoaded', function() {
                observer.observe(document.body, {
                    childList: true,
                    subtree: true
                });
                console.log('油猴脚本: MutationObserver 在 DOMContentLoaded 后启动');
            });
        }

        initialized = true;
        console.log('油猴脚本: 初始化完成');
    }

    // 立即执行弹窗拦截（document-start阶段）
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', interceptSeoModal);
    } else {
        interceptSeoModal();
    }

    // 尝试立即初始化
    initialize();

    // 延迟初始化（确保DOM完全加载）
    setTimeout(initialize, 1000);
    setTimeout(initialize, 3000);

    // 监听页面可见性变化（返回页面时重新初始化）
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden) {
            console.log('油猴脚本: 页面变为可见，重新初始化');
            setTimeout(initialize, 500);
            setTimeout(interceptSeoModal, 500);
            setTimeout(removeTopBanner, 500);
        }
    });

    console.log('油猴脚本: 脚本加载完成');
})();
